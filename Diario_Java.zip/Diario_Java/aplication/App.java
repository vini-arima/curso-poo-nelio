package aplication;

import model.Nota;
import model.Humor;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class App {
    public static void main(String[] args){
        Scanner scan = new Scanner(System.in);

        List<Nota> notas = new ArrayList<>() ;
        String path = "data/notas_do_diario.txt" ;

        try(BufferedWriter bw = new BufferedWriter(new FileWriter(path))) {
            System.out.println("Digite sua mensagem: ");
            String msg = scan.nextLine().trim() ;

            System.out.println("Digite o seu Humor (RAIVA, TRISTEZA , ALEGRIA):");
            String entry = scan.nextLine().trim() ;
            Humor emocao = Humor.valueOf(entry.toUpperCase()) ;

            System.out.println("Informe a Data (dd/mm/yyyy): ");

            DateTimeFormatter df =  DateTimeFormatter.ofPattern("dd/MM/yyyy") ;
            String input = scan.nextLine() ; 

            LocalDate date = LocalDate.parse(input, df);

            Nota ponto = new Nota(date, input, emocao) ;
            notas.add(ponto);

            for (Nota nota : notas) {
                bw.write(nota.toString());
                bw.newLine();
            }

        } catch (IOException e) {
           System.out.println("Error no arquivo" + e.getMessage());

        } catch (DateTimeParseException e){
            System.out.println("Error no formatato da data" + e.getMessage());
        }

        scan.close();


    }


}
