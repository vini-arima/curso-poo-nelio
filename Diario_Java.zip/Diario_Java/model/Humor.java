package model;

public enum Humor {
    RAIVA ,
    TRISTEZA , 
    ALEGRIA ;

}
