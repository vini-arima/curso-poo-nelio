package model;

import java.time.LocalDate;
import model.Humor;

public class Nota {
    private LocalDate date ;
    private String mensage ;
    private Humor emocao ;

    public Nota(LocalDate date, String mensage, Humor emocao) {
        this.date = date;
        this.mensage = mensage;
        this.emocao = emocao;
    }

    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public String getMensage() {
        return mensage;
    }

    public void setMensage(String mensage) {
        this.mensage = mensage;
    }

    public Humor getEmocao() {
        return emocao;
    }

    public void setEmocao(Humor emocao) {
        this.emocao = emocao;
    }

    public String toString(){
        return "Mensagem: " + mensage + " , " + "Data: " + date + " , " + "Humor: " + emocao ;
    }
    
}
