package service;

import java.util.ArrayList;
import java.util.List;

import model.Produtos;

public class ProdutoService {

    private List<Produtos> listaProdutos = new ArrayList<>();
    // CRUD

    public void adicionarProduto(int id, String nome, int qtd, double preco) {
        Produtos produto = new Produtos();
        produto.setId(id);
        produto.setNome(nome);
        produto.setQtd(qtd);
        produto.setPreco(preco);

        listaProdutos.add(produto);
        System.out.println("| Produto adicionado |");
    }

    // remover produto pelo ID - ISSO
    public void removerProduto(int id) {
        for (int i = 0; i < listaProdutos.size(); i++) {
            if (listaProdutos.get(i).getId() == id) {
                listaProdutos.remove(i);
                System.out.println("Produto removido");
            }
        }
        // verificar se o id não é igual - para não deletar os dois
        boolean encontrado = false;
        // Verificar se ID é igual
        for (Produtos item : listaProdutos) {
            if (item.getId() == id) {
                encontrado = true;
                break;
            }
        }
        if (!encontrado) {
            System.out.println("[ Produto não encontrado ]");
        } else {
            System.out.println("[ Produto encontrado ]");
        }
    }

    public void listarProdutos() {
        System.out.println("Lista de Produtos");

        if (listaProdutos.isEmpty()) {
            System.out.println("Nenhum produto encontrado.");
        } else {
            for (Produtos item : listaProdutos) {

                System.out.println("ID: " + item.getId());
                System.out.println("NOME " + item.getNome());
                System.out.println("QTD " + item.getQtd());
                System.out.println("PRECO " + item.getPreco());
                System.out.println("-----------------------");
            }
        }
    }

    public void mostrarProdutos() {
        System.out.println(" SISTEMA DE PRODUTOS");
        System.out.println(" 1 - Adicionar produto ");
        System.out.println(" 2 - Listar produto");
        System.out.println(" 3 - Remover produto ");
        System.out.println(" 0 - Sair do sistema ");
    }
}
