import java.util.Scanner;

import model.Produtos;
import service.ProdutoService;

public class Main {
    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);
        ProdutoService service = new ProdutoService();

        int opcao;
        do {

            service.mostrarProdutos();
            System.out.print(" Digite um numero: ");

            opcao = Integer.parseInt(scan.nextLine());

            switch (opcao) {
                case 1:
                    System.out.print("Quantos produtos você deseja registrar: ");
                    int N = Integer.parseInt(scan.nextLine());

                    for (int i = 0; i < N; i++) {
                        System.out.println("PRODUTO #" + (i + 1));

                        System.out.print("ID: ");
                        int id = Integer.parseInt(scan.nextLine());

                        System.out.print("Nome: ");
                        String nome = scan.nextLine();

                        System.out.print("Quantidade: ");
                        int qtd = Integer.parseInt(scan.nextLine());

                        System.out.print("Preço: ");
                        double preco = Double.parseDouble(scan.nextLine());

                        service.adicionarProduto(id, nome, qtd, preco);
                    }
                    break;
                case 2:
                    service.listarProdutos();
                    break;
                case 3:
                    System.out.print(" ID para remover: ");
                    int idRemover = Integer.parseInt(scan.nextLine());
                    service.removerProduto(idRemover);
                    break;

                case 0:
                    System.out.println("Saindo...");
                    break;
                default:
                    break;
            }
        } while (opcao != 0);

    }
}
